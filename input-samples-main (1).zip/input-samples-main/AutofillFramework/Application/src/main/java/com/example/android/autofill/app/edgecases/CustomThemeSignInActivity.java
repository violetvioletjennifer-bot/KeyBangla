/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.autofill.app.edgecases;

import android.os.Bundle;
import android.widget.TextView;

import com.example.android.autofill.app.commoncases.StandardSignInActivity;
import com.example.android.autofill.app.view.widget.InfoButton;
import com.example.android.autofill.app.R;

/**
 * Same as {@link StandardSignInActivity}, but using a custom theme (defined in the manifest).
 */
public class CustomThemeSignInActivity extends StandardSignInActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView title = findViewById(R.id.standard_login_header);
        title.setText(R.string.navigation_button_custom_theme_login_label);

        InfoButton info = findViewById(R.id.imageButton);
        info.setInfoText(getString(R.string.custom_theme_login_info));
    }
}
